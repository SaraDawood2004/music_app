import gridfs
from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["songapp"]
fs = gridfs.GridFS(db)

# Upload audio files
for filename in ["Tum hi ho.mp3", "Hasi.mp3", "Poo Nee Poo.mp3"]:
    with open(filename, "rb") as f:
        file_id = fs.put(f, filename=filename)
        print(f"Uploaded {filename} with file_id: {file_id}")
